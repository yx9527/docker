LINK_INTERFACE_MULTIPLICITY_<CONFIG>
------------------------------------

Per-configuration repetition count for cycles of ``STATIC`` libraries.

This is the configuration-specific version of
:prop_tgt:`LINK_INTERFACE_MULTIPLICITY`.  If set, this property completely
overrides the generic property for the named configuration.
