MANUALLY_ADDED_DEPENDENCIES
---------------------------

.. versionadded:: 3.8

Get manually added dependencies to other top-level targets.

This read-only property can be used to query all dependencies that
were added for this target with the :command:`add_dependencies`
command.
