TESTS
-----

.. versionadded:: 3.12

List of tests.

This read-only property holds a
:ref:`semicolon-separated list <CMake Language Lists>` of tests
defined so far, in the current directory, by the :command:`add_test` command.
